import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Batalla here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Batalla1 extends World
{

    /**
     * Constructor for objects of class Batalla.
     * 
     */
    public Batalla1()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1200, 650, 1); 
    }
}
